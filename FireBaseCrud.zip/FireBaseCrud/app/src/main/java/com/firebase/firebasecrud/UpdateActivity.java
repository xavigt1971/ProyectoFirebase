package com.firebase.firebasecrud;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.firebase.firebasecrud.model.MusicaVO;
import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class UpdateActivity extends AppCompatActivity {
    private EditText txtN, txtAlb, txtArt, txtGen;
    String idT, nombre, album, artista, genero;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;
    MusicaVO mvo = new MusicaVO();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);
        txtN = findViewById(R.id.nameTxtUD);
        txtAlb = findViewById(R.id.albumTxtUD);
        txtArt = findViewById(R.id.artistTxtUD);
        txtGen = findViewById(R.id.genereTxtUD);

        iniciarFirebase();
        datosRecibidos();
    }

    public void onClick(View view) {
        switch (view.getId()){
            case R.id.btnActualizar:
                update();
                break;
            case R.id.btnEliminar:
                delete();
                break;
        }
    }

    private void iniciarFirebase(){
        FirebaseApp.initializeApp(getApplicationContext());
        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference();
    }

    public void datosRecibidos(){
        Bundle bundle = getIntent().getExtras();
        idT = bundle.getString("id");
        nombre = bundle.getString("nombre");
        album = bundle.getString("album");
        artista = bundle.getString("artista");
        genero = bundle.getString("genero");
        txtN.setText(nombre);
        txtAlb.setText(album);
        txtArt.setText(artista);
        txtGen.setText(genero);
    }

    private void update(){
        if(!txtN.getText().toString().isEmpty()&&
                !txtAlb.getText().toString().isEmpty()&&
                !txtArt.getText().toString().isEmpty()&&
                !txtGen.getText().toString().isEmpty()){

            mvo.setId(idT);
            mvo.setNombre(txtN.getText().toString());
            mvo.setAlbum(txtAlb.getText().toString());
            mvo.setArtista(txtArt.getText().toString());
            mvo.setGenero(txtGen.getText().toString());

            databaseReference.child("Musica").child(mvo.getId()).setValue(mvo);
            Toast.makeText(this, "Datos Actualizados", Toast.LENGTH_SHORT).show();

    }else{
            Toast.makeText(this, "faltan datos", Toast.LENGTH_SHORT).show();
        }

    }

    private void delete(){
        if(!txtN.getText().toString().isEmpty()&&
                !txtAlb.getText().toString().isEmpty()&&
                !txtArt.getText().toString().isEmpty()&&
                !txtGen.getText().toString().isEmpty()){

            mvo.setId(idT);
            databaseReference.child("Musica").child(mvo.getId()).removeValue();

            Intent intent = new Intent(getApplicationContext(),MainActivity.class);
            startActivity(intent);

            Toast.makeText(this, "Datos Eliminados", Toast.LENGTH_SHORT).show();

        }else{
            Toast.makeText(this, "faltan datos", Toast.LENGTH_SHORT).show();
        }
    }
}
