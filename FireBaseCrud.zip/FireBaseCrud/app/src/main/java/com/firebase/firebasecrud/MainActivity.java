package com.firebase.firebasecrud;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.firebase.firebasecrud.model.MusicaVO;
import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private ListView lista;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;
    private ArrayList<MusicaVO> listaMusicaVO = new ArrayList<>();
    MusicaVO mvo = new MusicaVO();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lista = findViewById(R.id.listaId);
        iniciarFirebase();
        mostrarInfo();

        lista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                mvo = (MusicaVO) parent.getItemAtPosition(position);
                String idT = mvo.getId();
                String nom = mvo.getNombre();
                String alb = mvo.getAlbum();
                String ar = mvo.getArtista();
                String gen = mvo.getGenero();

                Intent intent = new Intent(getApplicationContext(), UpdateActivity.class);
                intent.putExtra("id",idT);
                intent.putExtra("nombre",nom);
                intent.putExtra("album",alb);
                intent.putExtra("artista",ar);
                intent.putExtra("genero",gen);

                startActivity(intent);


            }
        });
    }

    public void onClick(View view) {
        Intent intent = new Intent(this, InsertActivity.class);
        startActivity(intent);

    }



    private void iniciarFirebase(){
        FirebaseApp.initializeApp(getApplicationContext());
        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference();
    }

    private void mostrarInfo(){
        databaseReference.child("Musica").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
              //metodo de lista para limpiar
              listaMusicaVO.clear();
              for(DataSnapshot dataSnapshot : snapshot.getChildren()){
                  MusicaVO mvo = dataSnapshot.getValue(MusicaVO.class);
                  listaMusicaVO.add(mvo);
                  ArrayAdapter arrayAdapter = new ArrayAdapter(getApplicationContext(),android.R.layout.simple_list_item_1,listaMusicaVO );
                  lista.setAdapter(arrayAdapter);
              }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }


}
