package com.firebase.firebasecrud;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class EmpleadoCRUD extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_empleado_c_r_u_d);
    }
}
